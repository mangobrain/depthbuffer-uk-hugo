text-to-stereogram special bandcamp bonus edition
=================================================

Hello, friend!

If you're reading this, well done: you not only perused my album, you also took
the time to look at the bonus items, notice that one of them was just a URL,
download the archive, extract it, and find this README. You're either insane,
OCD, some kind of super-fan, or a combination of all three.

What you have here is the stereogram^1 generator I hacked up to generate my
Twitter & Bandcamp banner "art", as well as the magic eye portion of the Ataraxy
cover art. At some point I'll clean up the code and put it on Github, and you'll
be able to hack on it too & build it for other operating systems. In the
meantime, here's a pre-compiled version for 64-bit Windows, as I figure that's
probably what most people are on.

A base "tile" image is required as input. Make it tall and thin, as it will
be repeated horizontally across the end result. It also needs either a font file
(.ttf, .otf, etc.) and some text, or a greyscale depth map (black = far, white
= near) if you want to render actual 3D geometry. It has no GUI besides popping
up a window to display its output, so you'll need to run it from the command
line. From inside the folder containing this README, try the following:

text-to-stereogram.exe -t gold_tile.png -f font/Montserrat-BlackItalic.ttf -s 140 -w 1280 "Hello, world!"

Required options:
* -t <filename> to specify the tile image
* Either:
  * -f <filename> to specify a font, and some text at the end
  * -m <filename> to specify a depth map

Optional options:
* -w and -h to set output width and height
* -o <filename> to save the output to an image, e.g. -o foo.png
* -c to generate output for cross-eyed viewing (default is wall-eyed/divergent)

Additional options in text mode:
* -s <number> to specify font size
* -d <number> to specify text depth
  (1 = far, 255 = near; good values are around 20 to 80)

How does it work?
=================

Our brains use multiple visual cues to determine depth in 3D space: light and
shadow, how things change relative to each other they move or we move our heads,
learned expectations about the relative sizes of objects, and so on. But the
most direct and "mechanically obvious" is that, because of the space between our
eyes, we have to physically orient them in order to see a clear picture: to look
at something close to us, our eyes have to turn inwards towards each other; to
look at something far away, they turn outwards.

By taking a tall, thin image and repeating it horizontally at regular intervals,
you end up with something that can be viewed at "multiple distances": you can
look at it normally, or by intentionally orienting your eyes either inwards or
outwards by just the right amount, you can make each eye look at a different
repetition, but trick your brain into still holding position & maintaining sharp
focus, because it'll look like a single image again when it combines the two.
Depending on which way your eyes went (outwards or inwards), and how far (are
they looking at instances right next to each other, or did you go so cross-eyed
that they're actually looking two or three instances apart?), the image will
appear to jump forwards or backwards in space by fixed amounts.

By taking advantage of the fact that digital images are composed of grids of
tiny, individual pixels, if you take one of the image repetitions and shift
portions of it left or right by a few pixels - leaving the one to the left of
it unchanged, but treating the new, modified tile as "canonical" for any further
repetitions to the right - then, when you again make each eye look at a
different repetition, and have the brain interpret them as one, those portions
will appear slightly nearer or farther than the surrounding plane. By shifting
the horizontal strips marginally left or right, you force your eyes to have to
orient inwards/outwards to maintain the overlap that gives the illusion of a
single image; and by keeping those shifts small, it looks like an object with an
uneven surface, or a rectangle hovering in front of/behind a flat plane, as the
amount of re-orientation required is similar to when your eyes are tracking over
the surface of a real, physical object.

Taking this to its logical extreme:
* Take a tall, thin, rectangular input image, and decompose it into individual
  rows, each of which will be repeated horizontally as many times as required to
  fill the width of the final output image.
* For each row of the output image, first fill in one single "canonical" strip
  by taking an unmodified, one-pixel-high, horizontal slice of the input and
  copying it directly to the output, butting up against the left-hand edge.
  * Also, copy this horizontal strip into a ring buffer of pixels. The starting
    length of this buffer is the same as the width of the canonical strip, and
    the starting offset is zero.
* From here, go pixel by pixel, left to right, starting at the right-hand edge
  of the canonical strip just filled in.
* For each pixel:
  * You need to be able to decide: compared to its left-hand neighbour pixel, is
    it supposed to be closer to the viewer, further away, or at the same depth?
    This is where the greyscale depth map comes in.
    * If it's at the same depth, just fill in the output with the current pixel
      from the ring buffer.
    * If it's meant to be closer, you need to shorten your pattern (to force the
      eyes to orient inwards to maintain overlap when viewing). Look at the
      difference in depth between the current pixel and the one to its left:
      if you've gone from, for example, depth 10 to depth 15, where higher means
      closer, discard the next five pixels in the ring buffer (including the
      current one) before filling in the output.
      * It is important that you actually reduce the length of the ring buffer,
        not just jump forward by adding 5 to the offset.
    * If it's meant to be further away, you need to lengthen your pattern.
      You'll have to magically insert extra pixels into the ring buffer before
      taking from it to fill in the output.
      * Again, it is important that this actually lengthens the buffer, not just
        plays tricks with the offset.
  * Increment your ring buffer offset by one (wrapping around as appropriate),
    go to next pixel. When you reach the end of the row, start the whole process
    again one row down.

Problems with going deeper
==========================

The attentive reader may have noticed a glaring omission from the explanation
above: when lengthening the ring buffer, where do you get these mystery extra
pixels from? Well, the only thing that really matters is that they don't echo
anything else that might appear to their left in the final output row: if that
happens, you might create unintended short overlaps, and get "phantom objects"
that appear when viewing the image, repeating off to the right indefinitely.
If you ever look at a magic eye picture and can see the hidden object clearly,
but it has random spikes and floaty bits awkwardly repeating off to either the
left or right, someone's done a bad job of either choosing their extra pixels,
maintaining their buffer length, or both, and they should feel bad.

You can either make them up (literally, by picking random red, green, and blue
colour values), take them at random from the input tile (effectively giving you
a coherent "colour palette" to pick from), or - what I like to do - you can take
them horizontally from the input tile, in order, but not from the current row.

Initially, these extra pixels, because they don't overlap with anything when
they first appear (further to the right, they will overlap with themselves as
the pattern repeats - but at first they are unique), create "depth shadows".
If you have a rectangle hovering 5 "depth increments" above a flat plane, then
at the right-hand edge of the rectangle, where the depth drops down, there will
be a five-pixel-wide strip that might as well be filled with random garbage.
This is why large jumps in depth don't tend to work well in autostereograms:
you can't put anything immediately to the right of them (or left, depending on
your algorithm). Which explains why, aside from the obvious aesthetic
considerations, scenes in stereograms tend to comprise a single central object,
either floating in empty space, or resting on a flat surface.

Tips
====

* For text, big, bold, chunky fonts at large sizes work best. Otherwise the lack
  of light, shadow, colour, and all the other various depth cues - plus the
  depth shadows from the rendering process itself - cause the letters to simply
  get lost in the noise. This is why my example uses Montserrat Black at 140pt.
* Similarly, for 3D geometry, simple, blocky shapes work well. Again, due to the
  artefacting, don't hide something detailed behind & to the right of something
  else; it'll just get lost. Long, sweeping gradient changes in depth work
  well^2.
* The more colour variation in the tile, the more chance it stands of generating
  a good, clear, easy-to-view stereogram. Specifically, avoid horizontal bands
  of the same colour, or anything that repeats horizontally within the tile
  itself (unless it's also offset vertically). The less colour variation there
  is on each line, the less "raw information" there is available to the encoding
  process, and the greater the chance of getting random repeating "phantom
  objects" or regions where detail disappears because it's turned into a line
  of mostly the same colour^3.
* There are two kinds of autostereogram: ones designed to be viewed by going
  cross-eyed (described above), and ones designed to be viewed by going
  "wall-eyed" (eyes go outwards until there's an overlap, instead of inwards^4).
  Personally I find going intentionally cross-eyed much easier than going
  wall-eyed, and that I can do it by much larger amounts^5; hence, cross-eyed
  images tend to be easier to view when the image itself is physically big, but
  the smaller/more-zoomed-out it gets, the easier it becomes to accidentally
  overshoot the desired overlap and end up viewing mangled garbage. If you're
  going to use this for any serious artistic purpose, try both, and consider the
  trade-offs relevant to your expected viewing conditions: are you making
  something designed to be printed as a poster/billboard, or a small image for
  the web^6?
* To try and create more aesthetically pleasing images when using tiles that
  themselves contain actual, recognisable pictures, the code is all fancy and
  renders things in a two-step process: once to figure out which pixels of the
  tile end up where in the output, then it mangles the input tile and goes
  again. Specifically, it tries to arrange things such that the horizontal
  center of the image will contain the clearest representation of the original
  tile, instead of starting pristine on the left and getting progressively more
  garbled to the right.

Fin
===

I promise it's not a virus. I would never do that to you.
 - Phil

--

^1 Strictly speaking, "stereogram" originally referred to pair of two images;
   one for the left eye, and one for the right. This generates "single-image
   stereograms", or "autostereograms". I think the "auto" prefix stems from the
   fact that instead of being a pair of images, it's a single image that encodes
   both the left and right components in overlapping regions, so it "pairs with
   itself".

^2 In the Ataraxy art itself, I think the wings, skull, and pedestal are
   just about identifiable as such, but you can't really make out the fine
   detail *on* the pedestal without first cheating and looking at the depth map.
   You aren't missing much.

^3 In fact a lot of early single-image stereograms used completely random tiles,
   either black & white dots or random colour choices per pixel, giving rise to
   the name SIRDS (Single-Image Random Dot Stereogram). I think we can all agree
   that the marketing name Magic Eye is better.

^4 Wall-eyed stereograms are rendered exactly the same way, except that instead
   of shortening the pattern to make pixels closer and lengthening it to make
   pixels further away, you do the opposite.

^5 My layperson's pet theory on this is that, from an evolutionary perspective,
   it makes sense that we can quickly resolve detail & rapidly shift focus for
   objects close to us, as they're the ones a) likely to be in grasping range
   and b) most likely to be an immediate danger. So it makes sense that
   orienting our eyes inwards, to look at close things, is quick and easy to do
   in large amounts. ¯\_(ツ)_/¯

^6 I made the Ataraxy cover art cross-eyed, which in retrospect may have been a
   mistake, as it will most likely usually be viewed small, zoomed out, on a
   PC monitor or phone screen... but the original uncompressed image is actually
   pretty huge, so it made sense at the time. Also, this makes sense if maybe...
   it is one day printed out?

                                                                                                                                                                                                        
                                                                                                                                                                /###(##/                                
                                                                                                                                                        /&###%%%%&%%&&&&&&&&&&%(                        
                                                                                                                                                    *&##%%%%%%%&%%&&&&&&%&&&&&&&&&%%%%%%%%%%%(          
                                                                                                                                                  %%#%#%%%%%%%%&&&&&&&% ##& ,&&&&&&%(%%(*. .,*//**#%    
                                                                                                                                                %&%%%%%%%%%%%&&&&&&&&&.  (. &&&&#((//%%%&&&&&&(         
                                                                                                                                              (&%&%&&&&%%%#%%%&&&&&&&&&@&&&&&&&&&%%&&&                  
                                                                                                                                             %&&%&&&&&&%%%&%&&&&&&&&&&&&&&&&&&&&%                       
                                                                                                                                            &%&%%%&&&&%%%%&&&&&&&&&&&&&&&&&&&&&                         
                                                                                                                                         ./%%%%%%&%&%%&&&&&&&&&&&&&&&&&&&&&&%%                          
                                                                                                                                         %%%%%%%%%&&&&&&&&&&&&&&&&&&&&&%&&%&*                           
                                                                                                                                     .%&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&%%%(                            
                                                                                                                               *&&%%&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&%#                             
                                                                                                                          (###%%%&&&&#%&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&%&&%%                              
                                                                                                                      (%%##%%%&&&%%&&&&&&&&&&&&&&&&&&&&&&&#(/,,,,*%&&&&&%&                              
                                                                                                                   #%%%&&&&&%&&&&&&&&&&&&&&&&&&&&&&&&&&%#.,.......,,,&&&&&.                             
                                                                                                                 %%##%&%&&&&&&&&&&&&&&&&&&&&&&&&&&&&&%,............,,,(&&&%                             
                                                                                                              #&&%%&%%%&&&&&&&&&&&&&&&&&&&&&&&&&%%,,..............,,*&%&&&&                             
                                                                                                            %%%%#&&&&&&&&&&&&&&&&&&&&&&&&&&%%(**,,............,,,#&&%%##&&&                             
                                                                                                          /%%&&&%&&&&&&&&&&&%(&&&&&&&&&%&%(,,,,,,,,,,,,.,,.,,%&&&&&&%(#*%&&                             
                                                                                                        (&&%&&&&&&&&&&&&&%(*,/&&&&&&%&&&/,,,,,,,,,,,,,,,/#%%%%&&&&&&(,,,,&#                             
                                                                                                     ,%&%%&&&&&&&&&&&%%%&%%&&&&&&&%%%&%%&%###%%%%#%%%%%%%%&&&&&&&%,.,,,,,&                              
                                                                                                  .%%%%%%%&&&&%%%%%%%%%%%%%%&&&&&%&&%%%%%%%%%%%%%%%#%%%%%%%%%#*,,,,,,,,,/,                              
%%,                                                                                            ,%%%%%%%%%%%%%%%%%%%%((#%&&%%&%&%&#%##(####%%%#%%&%%#%%%#/,,,.,....,,,,**/                               
((##%%%(.                                                                                   *%%%%%%%%%%%%%%%##%%%&%##%&%%#%&&%%&%%%###((/*,,.,..,...............,,,,,,*                                 
###(((((###%%*                                                                            %%%%%%%%%%%%%%#%&%#%&%#%&%%#%&%%%%%%%%#*,,,,,,,,,,,,,.................,,,,***                                 
%%%%%####(((((###%%/*                                                                  (%%%%%%%%%#%%&&&&&%&&%%&&@@@&&&&&%&&((***,,,,,,,,,,..........,..,,,,,,,,,,,**/                                   
%%%%%%%%%%#####((((((###%%*                                                         #%%&&&%%&&&&&&&&@@@&&&&@&&&&&&&&&&&&%%(***,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,/*                                    
%%%%%%%%%%%%%%%%%###(((((((((##%#.                                              &&&&&&&&&&@@&&&&&&&&&&&&&&&&&&&&&&&&&&&&##//*****,,,,,,,,,,,,,,,,,,,,,,,,,,,,,***/                                      
%&%&&%%%%%%%%%%%%%%%%######(((//(((##%%.                                   (&&&&/*  %&&&&&&%%%%%&&&&@@&@&&&&&&&&&&&&&&&&&&%(//***,,,,,,,,,,,,,,,,,,,,,,,,,,,,*,(                                        
&%&&%%%&&%%%%%%%%%%%%%%%%%%%#####((/////(##%(                          &&&/      .&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&%%(/*******,*,,,,,,,,,,,,,,,*****/(                                          
%&%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%#%#####((////((#%%/                .&.         %&&&&&&&&&%&&&&&&&&&&&&&&&&&&&&&@&&&&&&&&&&&%(&#//******,,,,,,,,,,,,******//*                                            
&&%&%%&%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%####((//*//(##%/                   %&&&&&&&%%&&&&&&&&&&&&&&&&&&@&&&&&&&&&&&&@&&&&&&&%##//************,,,**,**/(/                                               
&&&&&%&&&%%%%&&&%%%%%%%%%%%%%%%%%%%%%%%%%%%%#######((//*//((#%#           &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&%%/##(//*********,*/(/                                                   
&&&&%&&&&&&%%&%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%#%%%%###(//***/((#%. /&&&&&&&&&&&&&&&&&&&&&&&&&&@@@@@&&@@@@@@&@@&&&&&&&&&&&&&&&&&&%((//*****//#%*                                                      
&&&&&&&&&&&%%&%%&%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%###((,  &&&&&&&&&&&&&&&&&&&&&&/          *&&&&@@@&@@&@@@&&&&&&&&&&&&&&&&#/(((((#%&                                                           
&&&&&&&&%%%%&%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%* .&&&&&&&&&&&&&&&&&&&&&%.                     */%&&@@@@@@&&&&&&&&&&&&&&&%&&&,&&                                                            
&&&&&&&&&%%&%%%%%%&&&%&&&&%%%%%%%%%%%%%%%&&%%%%%%%%%%%%*  %&&&&&&&&&&&&&&&&&&&&,  /(#/                         %&@@@@@@@&&&&&&&&&&&&%                                                                   
&&&&&&&&&&&&&%%%&%&&%%%%%%&&&%%%%%%%%%%%%%%%&%%%%%%  (&&&&&&&&&&&&&&&&&&&&&  (%%#(/*****/(#/                   &&&@@@@@@@ &&&&&&&&&%                                                                    
&&&&&&&&&&&&&&&&&&&%&%%%%%%&&&&&&&&%%%%%%%%&%%%. (&&&&&&&&&&&&&&&&&&&&&  (&&&&&%%%%%%%%%(/****/(#/              &&@@@@&&& ,&@&&&&/                                                                      
&&&&&&&&&&&&&&&&&&&&&&&&%&&&&&&&&&&&%%%%%&&/  &&&&&&&&&&&&&&&&&&&&*  %&&&&&&&&&&&&&&&%%%%%%%%%#(****/(#          ,&&&&@@.    ,&&&&                                                                      
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&, .&&&&&&&&&&&&&&&&&&&@#  &&&&&&&&&&&&&&&&&&&&&&&&&%%%%%%%%%%#/****/((       ,%&&@&%     &&&&                                                                    
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&  #&&&&&&&&&&&&&&&&&&@&(  (&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&%%%%%%%%%%(/*/**/((    /#&&&&(    %&&&                                                                  
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&  &&&&&&&&&&&&&&&&@&  /&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&%%%%%%%%%%#****/(#, ,/&&&&#   &@&&                                                                
&&&&&&&&&&&&&&&&&&&&&&&&&&&&,  &@&&&&&&&&&&&&&@&(  &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&%%&%%%%%%%%%%%#***//((%&&&&(  &&&&                                                              
&&&&&&&&&&&&&&&&&&&&&&&&&  %&@&@&&&&&&&&&@&@&  %&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&%&&&&&&&%%&&&&%%%%%%%%%%%(**/(&&&&&&#&&&&                                                            
&&&&&&&&&&&&&&&&&&&&&%  &@@@&&&&&&&&&@&&&&  &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&%&&&&&&&&&&&&&&%%&&&&&%%%%%%%%%%%(%&&&&&&&&&&                                                          
&&&&&&&&&&&&&&&&&(  @@@@@&&&&&&&&&@&@&&* #&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&%&&&%&&&&&&&&%&%&%%%%%&&&&&&&&&&@&&&&&&&&.                                                   
&&&&&&&&&&&&&/  @&&@@@&&&&&&&&@@@@@&&  &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&%&&&&&&&&%&%%&%%%&&&&&&&&&&&&&&&&&&&&&&&&&&&&%                                             
&&&&&&&&&&&&& @ .&&&&&&&&&( .&&@@&& %&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&%&&&%&&&&&&&&&&&&&%%&&@&%&&&&&&&&&&&&%&&%%%((%&&&%%&                                           
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&%&&&&&%&&&&&&&%%&&%%&&%&&&&&&&&&&&%%%%&%%%%%%/*///*(                                       
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&%&%&&&&%%&&&&&&&&&&&&&%%%%%%%&&&%%%%#****(//*.                               
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&%&&&&&&&&&&&&&&&&&%%&%&%%%&&&&&&&&&&&&&&&&&%&%&&%%%&&&&&%%%/**/*/(                           
&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&%&&&&&&&&&%&&&&&&&&&&&&&&&&&&&&&&&&%&&&&&&&&&%%#*////#                     
